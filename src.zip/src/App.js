import React, { useEffect, useState } from "react";
import './App.css';

const App = () => {
    const [state, setState] = useState({ dizi: [1, 2, 3, 4, 5], toplam: 0, pageCount: 12, totalRecord: 200, number1: 250 });
    const [total, setTotal] = useState(0);
    const [array, setArray] = useState([]);


    useEffect(() => {
        console.log("Constrocter");
    });

    useEffect(() => {
        console.log("Constrocter");
    }, []);


    useEffect(() => {
        console.log(state.pageCount);
    }, [state.dizi.length]);

    const hesapla = (x, y) => {
        const toplam = x * y;
        state.dizi.push(toplam);
        if (toplam > 20) {
            state.pageCount++;
        }
        setState({ ...state, toplam });
    }

    function sayHello() {
        alert("say hello");
    }
    

    return (<>
        
        <button style={{ background: "red" }} onClick={() => hesapla(5, 7)}>Topla</button>
        <div><button style={{ background: "red" }} onClick={sayHello}>Say Hello</button></div>
        <h2>Sayi 1:{state.number1}</h2>
        <h2>Sayi 2:{state.number2}</h2>
        <h1>Sonuc:{state?.toplam}</h1>
    </>);
}

export default App;